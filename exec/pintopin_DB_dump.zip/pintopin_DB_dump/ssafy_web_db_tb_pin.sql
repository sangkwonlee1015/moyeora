-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: i7a407.p.ssafy.io    Database: ssafy_web_db
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_pin`
--

DROP TABLE IF EXISTS `tb_pin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_pin` (
  `pin_seq` bigint NOT NULL AUTO_INCREMENT,
  `map_seq` bigint DEFAULT NULL,
  `pin_color` varchar(255) DEFAULT NULL,
  `pin_content` varchar(255) DEFAULT NULL,
  `pin_flag` int DEFAULT NULL,
  `pin_lat` varchar(255) DEFAULT NULL,
  `pin_lng` varchar(255) DEFAULT NULL,
  `pin_order` int DEFAULT NULL,
  `pin_title` varchar(255) DEFAULT NULL,
  `user_seq` bigint DEFAULT NULL,
  PRIMARY KEY (`pin_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pin`
--

LOCK TABLES `tb_pin` WRITE;
/*!40000 ALTER TABLE `tb_pin` DISABLE KEYS */;
INSERT INTO `tb_pin` VALUES (2,1,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'33.47866074455451','126.90636648646604',0,'올레길 1코스(시흥-광치기 올레)',1),(3,1,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,1,'33.44016934645293','126.90186955925942',0,'올레길 2코스(광치기-온평 올레)',1),(4,1,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,1,'33.30481622383354','126.78792799112594',1,'올레길 4코스(표선-남원 올레)',1),(5,1,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,1,'33.27078076230098','126.66743988738492',2,'올레길 5코스(남원-쇠소깍 올레)',1),(6,1,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,1,'33.24127212174994','126.59230607000688',3,'올레길 6코스(쇠소깍-서귀포 올레)',1),(7,1,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,1,'33.23738579332568','126.51530966206293',4,'올레길 7코스(서귀포-월평 올레)',1),(8,1,'/static/media/PinPink.c8c43390a967034ed89a2fa1fa53cc23.svg',NULL,1,'33.258895288625645','126.40715814631936',5,'연돈',1),(9,2,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'37.7950741626953','128.896636344738',0,'경포대',2),(10,2,'/static/media/PinOrange.1594a2d2b9d2a5ba7045d02cfa8e564b.svg',NULL,0,'37.7905546548915','128.915396082152',1,'초당할머니순두부',2),(18,3,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'37.50895738761964','127.05099820109564',0,'New Pin 37.51 127.05',13),(19,3,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'37.50600352671804','127.0475579922159',1,'New Pin 37.51 127.05',13),(20,3,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'37.505355341754125','127.04620040876786',2,'New Pin 37.51 127.05',13),(21,3,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg','강남역에서 볼까??',0,'37.50153584089231','127.04420763731996',3,'New Pin 37.50 127.04',13),(22,3,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg','여기가자!!!!',0,'37.49447217113519','127.04361545082592',4,'New Pin 37.49 127.04',14),(23,3,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg','여기가 우리집에서 더 가까운데??',0,'37.49756169650556','127.06519404321517',5,'New Pin 37.50 127.07',13),(24,3,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'37.28133115739257','127.02666812259683',6,'New Pin 37.28 127.03',13),(25,3,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'37.48960707970225','127.04266280084377',7,'New Pin 37.49 127.04',14),(57,5,'/static/media/PinRed.c8332ae9001cb8e022fa0eeeeba0e057.svg',NULL,1,'38.29297696193639','128.54180711633953',1,'백촌막국수',16),(80,6,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'37.50723249730087','127.03755503061127',0,'New Pin 37.51 127.04',21),(81,6,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'37.50762568049441','127.0466937977676',1,'New Pin 37.51 127.05',21),(87,7,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'38.12250793037983','128.57612142132993',0,'영광정메밀국수',18),(91,7,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg','맛있겠당!!',0,'38.0705738764976','128.628000494829',1,'감나무식당',18),(94,5,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,1,'38.0705738764976','128.628000494829',0,'감나무식당',17),(107,5,'/static/media/PinYellow.2fee51cdd2072bf6441a989a3ca485b2.svg',NULL,1,'38.04796914616583','128.68633943966125',3,'수산항물회',17),(108,5,'/static/media/PinYellow.2fee51cdd2072bf6441a989a3ca485b2.svg',NULL,1,'38.07534905422961','128.62325628561794',2,'공가네감자옹심이',17),(109,5,'/static/media/PinYellow.2fee51cdd2072bf6441a989a3ca485b2.svg',NULL,1,'37.96859178746601','128.76188883773875',4,'플리즈웨잇',17),(110,5,'/static/media/PinYellow.2fee51cdd2072bf6441a989a3ca485b2.svg',NULL,0,'38.13286351411941','128.6189276097294',0,'범바우막국수',17),(115,5,'/static/media/PinGreen.e568cd6a253d10148bca2ca8a2553cac.svg',NULL,1,'38.08044881273271','128.62747754600161',5,'수라상',17),(117,5,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'38.021097161847045','128.7351329269287',1,'하조대',15),(119,5,'/static/media/PinBlack.ea7e9836d51bddc8ec1119772ffae55c.svg',NULL,0,'38.1190961037351','128.465164820694',2,'설악산 대청봉',15);
/*!40000 ALTER TABLE `tb_pin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:14:28
